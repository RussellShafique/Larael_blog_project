<?php $__env->startSection('title', '| Homepage'); ?>

<?php $__env->startSection('content'); ?>

      <div class="row">
      
          <div class="col-md-12">
                      <div class="jumbotron">
              <h1>Welcome to the journey!</h1>
                          <p class="lead">This is a website about traveling in Bangladesh. Read the posts to learn about it. Hope you will enjoy!</p>
              <p><a class="btn btn-primary btn-lg" href="#" role="button">Popular post</a></p>
            </div>
          </div>
      </div>  <!-- end of header row-->
      
       <div class="row">
           <div class="col-md-8">
               
               
               <div class ="Post">
               <h3>Post Title</h3>
                   <p>hfufiufufiytduyrdudutrd</p>
                   <a href='#' class="btn btn-primary">Read More</a>
               </div>
               
   <hr>
                 <div class ="Post">
               <h3>Post Title</h3>
                   <p>hfufiufufiytduyrdudutrd</p>
                   <a href='#' class="btn btn-primary">Read More</a>
               </div>
               

   <hr>
               <div class ="Post">
               <h3>Post Title</h3>
                   <p>hfufiufufiytduyrdudutrd</p>
                   <a href='#' class="btn btn-primary">Read More</a>
               </div>
               
               
                
   <hr>
                 <div class ="Post">
               <h3>Post Title</h3>
                   <p>hfufiufufiytduyrdudutrd</p>
                   <a href='#' class="btn btn-primary">Read More</a>
               </div>
               
   <hr>
               
           </div>
           <div class="col-md-3 col-md-offset-1">
               <h2>Sidebar</h2>
           </div>
      </div>
      
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>